/* CONFIG — isi PROXY_URL ke backend kamu. Secret TIDAK ada di sini. */
window.__SYAM_CFG__={
  PROXY_URL:"", /* contoh: "https://domainmu.com/backend/proxy.php" atau "http://localhost:3001/api/qris" */
  WA_ADMIN:"6285656564944"
};
