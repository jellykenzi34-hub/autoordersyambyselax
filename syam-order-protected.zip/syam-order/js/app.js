(function(){
'use strict';
var C=window.__SYAM_CFG__||{};
var S={a:0,l:'',t:'',tid:null,ta:0,qr:null,pu:null,p:false,lc:0};
var bp='member',pt=null;
function $(i){return document.getElementById(i)}
function q(s,c){return(c||document).querySelectorAll(s)}
function toast(m,d){var t=$('toast');if(!t)return;t.textContent=m;t.classList.add('show');clearTimeout(t._t);t._t=setTimeout(function(){t.classList.remove('show')},d||3200)}
function go(pg){q('.page').forEach(function(p){p.classList.remove('active')});var e=$('p-'+pg);if(e)e.classList.add('active');window.scrollTo(0,0);if(pg!=='pay')stopP()}
function fr(n){return'Rp'+Number(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g,'.')}
function callAPI(prm){
  var b=new URLSearchParams(prm);
  var url=C.PROXY_URL;
  if(!url){toast('PROXY_URL belum diisi di config.js');return Promise.reject(new Error('No proxy'))}
  return fetch(url,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:b.toString()}).then(function(r){return r.json()});
}
function startPay(f){if(!S.a||S.a<1000){alert('Pilih nominal dulu');return}bp=f;S.tid=null;S.p=false;S.lc=0;go('pay');$('plbl').textContent=S.l+' · Scan QR untuk bayar';$('btn-cp').disabled=true;mkQR()}
function mkQR(){
  var ld=$('ql'),ct=$('qc'),er=$('qe');
  ld.classList.remove('hd');ct.classList.add('hd');er.classList.add('hd');
  callAPI({action:'api_create_qris',amount:String(S.a),description:'Order Syam - '+S.l,fee_by:'user',app_name:'OrderSyamBySelax',app_version:'1.0'})
  .then(function(j){
    if(!j.success||!j.data)throw new Error(j.message||'Gagal');
    var d=j.data;S.tid=d.transaction_id;S.ta=d.total_amount||d.amount;S.qr=d.qr_url||d.qris_image;S.pu=d.payment_url||null;
    $('qi').src=S.qr;$('qa').textContent=fr(S.ta);
    $('qti').textContent=(d.amount_uniq?('Kode unik +'+d.amount_uniq):'')+(d.admin_fee?(' · Fee '+fr(d.admin_fee)):'');
    $('qoi').textContent='ID: '+S.tid;$('qs').textContent='MENUNGGU PEMBAYARAN';$('qs').className='sb sp';
    if(S.pu){$('bpu').href=S.pu;$('bpu').style.display=''}else{$('bpu').style.display='none'}
    ld.classList.add('hd');ct.classList.remove('hd');$('btn-cp').disabled=false;startP();toast('QRIS berhasil dibuat');
  }).catch(function(e){ld.classList.add('hd');ct.classList.add('hd');er.classList.remove('hd');$('qem').textContent=e.message||'Gagal membuat QRIS'});
}
function chk(){
  if(!S.tid)return Promise.resolve(null);
  var n=Date.now();if(n-S.lc<20000)return Promise.resolve({rl:true,w:Math.ceil((20000-(n-S.lc))/1000)});
  S.lc=n;
  return callAPI({action:'api_check_status',transaction_id:S.tid}).then(function(j){
    if(!j.success){if(j.error==='rate_limited')return{rl:true,w:j.retry_after||20};return{e:j.message||'Gagal'}}
    return{s:j.data.status,d:j.data};
  }).catch(function(e){return{e:e.message||'Network'}});
}
function manChk(){
  var btn=$('btn-cp'),st=$('qs');btn.disabled=true;btn.textContent='MENGECEK...';st.textContent='SEDANG DICEK...';st.className='sb sc';
  chk().then(function(r){
    if(r&&r.rl){st.textContent='TUNGGU '+r.w+' DTK';st.className='sb sc';alert('Tunggu '+r.w+' detik.');btn.disabled=false;btn.textContent='SAYA SUDAH BAYAR';return}
    if(r&&r.e){st.textContent='GAGAL CEK';st.className='sb sp';alert('Gagal: '+r.e);btn.disabled=false;btn.textContent='SAYA SUDAH BAYAR';return}
    var s=(r&&r.s)?r.s:'pending';
    if(s==='success'){S.p=true;st.textContent='PEMBAYARAN DITERIMA';st.className='sb spd';stopP();toast('Pembayaran berhasil!');setTimeout(function(){go('req')},900)}
    else if(s==='expired'||s==='failed'){st.textContent=s==='expired'?'QR KEDALUWARSA':'GAGAL';st.className='sb se';alert('Transaksi '+s);btn.disabled=false;btn.textContent='SAYA SUDAH BAYAR'}
    else{st.textContent='BELUM TERDETEKSI';st.className='sb sp';alert('Pembayaran BELUM terdeteksi.\nPastikan nominal benar.\nTunggu 10-30 detik.');btn.disabled=false;btn.textContent='SAYA SUDAH BAYAR'}
  });
}
function startP(){stopP();pt=setInterval(function(){if(S.p||!S.tid)return;chk().then(function(r){if(!r||r.rl||r.e)return;var st=$('qs');if(r.s==='success'){S.p=true;st.textContent='PEMBAYARAN DITERIMA';st.className='sb spd';stopP();toast('Pembayaran berhasil terdeteksi!');setTimeout(function(){go('req')},900)}else if(r.s==='expired'||r.s==='failed'){st.textContent=r.s==='expired'?'QR KEDALUWARSA':'GAGAL';st.className='sb se';stopP()}})},25000)}
function stopP(){if(pt)clearInterval(pt);pt=null}
function subReq(){
  if(!S.p){alert('Pembayaran belum terverifikasi.');go('pay');return}
  var u=$('ru').value.trim(),p=$('rp').value.trim();if(!u||!p){alert('Username dan Password wajib');return}
  var tx='*ORDER SYAM BY SELAX*\n━━━━━━━━━━━━━━\n📦 Produk : APK BUG X RAT SYAM\n🏷️ Paket  : '+S.l+'\n💰 Nominal: '+fr(S.ta||S.a)+'\n🆔 Trx ID : '+S.tid+'\n━━━━━━━━━━━━━━\n👤 Username : '+u+'\n🔑 Password : '+p+'\n━━━━━━━━━━━━━━\n✅ Status : PEMBAYARAN TERVERIFIKASI\nMohon aktifkan akun.';
  window.open('https://wa.me/'+(C.WA_ADMIN||'')+'?text='+encodeURIComponent(tx),'_blank');toast('Order dikirim ke admin');go('ok');
}
function subCS(){
  var m=$('cm').value.trim(),w=$('cw').value.trim();if(!m){alert('Isi laporan');return}if(!w){alert('Isi nomor WA');return}
  var tx='*LAPORAN MASALAH — SYAM*\n━━━━━━━━━━━━━━\n📱 WA Pelapor : '+w+'\n📝 Laporan :\n'+m+'\n━━━━━━━━━━━━━━\nMohon ditindaklanjuti.';
  window.open('https://wa.me/'+(C.WA_ADMIN||'')+'?text='+encodeURIComponent(tx),'_blank');toast('Laporan dikirim');
}
function selFull(t){
  $('bl').className=t==='lunas'?'btn':'btn bo';$('bd').className=t==='dp'?'btn':'btn bo';
  if(t==='lunas'){$('dpo').classList.add('hd');$('li').classList.remove('hd');S.a=50000;S.l='Full Up Lunas';S.t='fullup';$('bpf').disabled=false}
  else{$('li').classList.add('hd');$('dpo').classList.remove('hd');S.a=0;$('bpf').disabled=true;q('#dpo .pi').forEach(function(i){i.classList.remove('sel')})}
}
function dlQR(){if(!S.qr)return;var a=document.createElement('a');a.href=S.qr;a.download='qris-syam-'+(S.tid||'o')+'.png';a.target='_blank';a.click()}
document.addEventListener('keydown',function(e){if(e.key==='F12'||(e.ctrlKey&&e.shiftKey&&(e.key==='I'||e.key==='J'||e.key==='C'))||(e.ctrlKey&&(e.key==='u'||e.key==='s'))){e.preventDefault();e.stopPropagation();toast('Aksi tidak diizinkan');return false}});
document.addEventListener('contextmenu',function(e){e.preventDefault();toast('Klik kanan dinonaktifkan');return false});
function bind(){
  q('[data-g]').forEach(function(el){el.addEventListener('click',function(){go(el.getAttribute('data-g'))})});
  var bbp=$('bbp');if(bbp)bbp.addEventListener('click',function(){go(bp)});
  var bcp=$('btn-cp');if(bcp)bcp.addEventListener('click',manChk);
  var bdq=$('bdq');if(bdq)bdq.addEventListener('click',dlQR);
  var brt=$('brt');if(brt)brt.addEventListener('click',mkQR);
  var bsr=$('bsr');if(bsr)bsr.addEventListener('click',subReq);
  var bcs=$('bcs');if(bcs)bcs.addEventListener('click',subCS);
  var bl=$('bl');if(bl)bl.addEventListener('click',function(){selFull('lunas')});
  var bd=$('bd');if(bd)bd.addEventListener('click',function(){selFull('dp')});
  var bpm=$('bpm');if(bpm)bpm.addEventListener('click',function(){startPay('member')});
  var bpf=$('bpf');if(bpf)bpf.addEventListener('click',function(){startPay('fullup')});
  q('#mp .pi').forEach(function(el){el.addEventListener('click',function(){q('#mp .pi').forEach(function(i){i.classList.remove('sel')});el.classList.add('sel');S.a=parseInt(el.getAttribute('data-a'),10);S.l=el.getAttribute('data-l');S.t='member';$('bpm').disabled=false})});
  q('#dpo .pi').forEach(function(el){el.addEventListener('click',function(){q('#dpo .pi').forEach(function(i){i.classList.remove('sel')});el.classList.add('sel');S.a=parseInt(el.getAttribute('data-a'),10);S.l=el.getAttribute('data-l');S.t='fullup';$('bpf').disabled=false})});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind);else bind();
})();
