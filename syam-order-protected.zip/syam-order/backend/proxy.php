<?php
/**
 * BUATQRIS PROXY (PHP)
 * Secret token HANYA di sini. Frontend tidak pernah melihat.
 * Upload ke hosting PHP, lalu set PROXY_URL di config.js
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['success'=>false,'message'=>'Method not allowed']); exit;
}

$ACCOUNT_ID = getenv('BUATQRIS_ACCOUNT_ID') ?: 'user_6ab87ba7cd9c17.39096173';
$SECRET     = getenv('BUATQRIS_SECRET')     ?: 'sk_live_505a5fc309644d8da9422c62f457b7f91a7b891054b2070a1d55e2dd31713f46';

$action = $_POST['action'] ?? '';
$allowed = ['api_create_qris','api_check_status'];
if (!$action || !in_array($action, $allowed, true)) {
  echo json_encode(['success'=>false,'message'=>'Action tidak valid']); exit;
}

$params = [
  'action'       => $action,
  'account_id'   => $ACCOUNT_ID,
  'secret_token' => $SECRET,
];

if ($action === 'api_create_qris') {
  $params['amount']      = $_POST['amount'] ?? '';
  $params['description'] = $_POST['description'] ?? 'Order Syam';
  $params['fee_by']      = $_POST['fee_by'] ?? 'user';
  if (!empty($_POST['qris_method'])) $params['qris_method'] = $_POST['qris_method'];
  if (!empty($_POST['app_name']))    $params['app_name'] = $_POST['app_name'];
  if (!empty($_POST['app_version'])) $params['app_version'] = $_POST['app_version'];
} else {
  $params['transaction_id'] = $_POST['transaction_id'] ?? '';
}

$ch = curl_init('https://api.buatqris.site');
curl_setopt_array($ch, [
  CURLOPT_POST           => true,
  CURLOPT_POSTFIELDS     => http_build_query($params),
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_TIMEOUT        => 30,
  CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
]);
$response = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err = curl_error($ch);
curl_close($ch);

if ($err) { echo json_encode(['success'=>false,'message'=>'Proxy error: '.$err]); exit; }
http_response_code($code ?: 200);
echo $response;
