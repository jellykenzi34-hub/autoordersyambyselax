/**
 * BUATQRIS PROXY BACKEND
 * =====================
 * Secret token HANYA ada di sini.
 * Frontend TIDAK pernah melihat secret.
 *
 * Install: npm install express cors
 * Run:     node server.js
 * Env:     BUATQRIS_ACCOUNT_ID=...  BUATQRIS_SECRET=...  PORT=3001
 */

const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors({ origin: true }));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const ACCOUNT_ID = process.env.BUATQRIS_ACCOUNT_ID || 'user_6ab87ba7cd9c17.39096173';
const SECRET = process.env.BUATQRIS_SECRET || 'sk_live_505a5fc309644d8da9422c62f457b7f91a7b891054b2070a1d55e2dd31713f46';
const API = 'https://api.buatqris.site';

const ALLOWED = new Set(['api_create_qris', 'api_check_status']);

app.post('/api/qris', async (req, res) => {
  try {
    const action = req.body.action;
    if (!action || !ALLOWED.has(action)) {
      return res.status(400).json({ success: false, message: 'Action tidak valid' });
    }

    const params = new URLSearchParams({
      action,
      account_id: ACCOUNT_ID,
      secret_token: SECRET
    });

    if (action === 'api_create_qris') {
      params.set('amount', String(req.body.amount || ''));
      params.set('description', req.body.description || 'Order Syam');
      params.set('fee_by', req.body.fee_by || 'user');
      if (req.body.qris_method) params.set('qris_method', req.body.qris_method);
      if (req.body.app_name) params.set('app_name', req.body.app_name);
      if (req.body.app_version) params.set('app_version', req.body.app_version);
    } else if (action === 'api_check_status') {
      params.set('transaction_id', req.body.transaction_id || '');
    }

    const r = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });

    const data = await r.json();
    res.status(r.status).json(data);
  } catch (err) {
    res.status(500).json({ success: false, message: 'Proxy error: ' + err.message });
  }
});

app.get('/health', (_, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log('[BuatQris Proxy] running on http://localhost:' + PORT);
  console.log('[BuatQris Proxy] endpoint: POST /api/qris');
});
