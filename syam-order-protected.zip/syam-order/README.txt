========================================
  ORDER SYAM BY SELAX — SETUP
========================================

STRUKTUR:
  index.html          → halaman utama
  css/style.css       → tema liquid glass
  js/config.js        → konfigurasi (PROXY_URL + WA)
  js/app.js           → logic frontend (obfuscated, TANPA secret)
  backend/server.js   → proxy Node.js (SECRET di sini)
  backend/proxy.php   → proxy PHP (SECRET di sini)

----------------------------------------
1. PENTING: SECRET TIDAK ADA DI FRONTEND
----------------------------------------
Secret token hanya ada di folder backend/.
Frontend hanya hit PROXY_URL.

----------------------------------------
2. CARA PAKAI BACKEND
----------------------------------------

A) PHP (paling gampang di hosting shared)
   - Upload backend/proxy.php ke hosting
   - Contoh URL: https://domainmu.com/proxy.php
   - Buka js/config.js, isi:
     PROXY_URL: "https://domainmu.com/proxy.php"

B) Node.js
   - cd backend
   - npm install express cors
   - node server.js
   - Default: http://localhost:3001/api/qris
   - Di config.js:
     PROXY_URL: "http://localhost:3001/api/qris"
   - Production: set env
     BUATQRIS_ACCOUNT_ID=user_xxx
     BUATQRIS_SECRET=sk_live_xxx
     PORT=3001

----------------------------------------
3. PROTEKSI YANG ADA
----------------------------------------
- Klik kanan disabled
- F12 / Ctrl+U / Ctrl+S / Ctrl+Shift+I dicegah
- user-select none
- JS minify + nama pendek
- Secret TIDAK pernah dikirim ke browser

Catatan: proteksi frontend tidak 100%.
Yang bikin aman adalah secret di backend.

----------------------------------------
4. TOAST NOTIF
----------------------------------------
Muncul di bawah layar saat:
- QRIS dibuat
- Pembayaran sukses
- Order dikirim
- Laporan CS
- Aksi terlarang

